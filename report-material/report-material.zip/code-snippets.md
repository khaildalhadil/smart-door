# Smart Door Lock — Main Code Snippets

These are the key parts of the code behind each main feature. Each snippet is copied from the project source. Some are shortened to show the main idea: logging and error handling are removed, and `...` marks other removed lines. The file path is shown above each one.

Languages used: Python 3 on the Raspberry Pi (door panel, sensors, API), JavaScript on Node.js (WhatsApp bot), SQL (Supabase database), and TypeScript + React (web dashboard).

## 1. Opening the door safely (relay control with auto-lock)

File: `app/lock.py`

The door opens by switching a relay for a few seconds. The time is always capped, and a background "supervisor" thread locks the door again when the time runs out. If anything fails, the lock stays shut (fail-secure).

```python
def unlock(self, seconds: float | None = None, reason: str = "") -> bool:
    """Energise the relay for ``seconds`` (clamped), then auto-lock."""
    duration = self.config.unlock_seconds if seconds is None else float(seconds)
    ceiling = self.config.getfloat("lock", "max_unlock_seconds", 10.0)
    duration = max(0.2, min(duration, ceiling))

    with self._lock:
        if self._closed:
            return False
        ok = self._apply(True)
        if not ok:
            self._state = LockState.LOCKED
            ...
            return False
        self._state = LockState.UNLOCKED
        # Extend rather than stack: one deadline, one supervisor.
        self._deadline = max(self._deadline, time.monotonic() + duration)
        self._wake.notify_all()

    if self.events:
        self.events.info("lock.unlock", f"{duration:.1f}s" + (f" ({reason})" if reason else ""))
    self._notify()
    return True
```

```python
# Supervisor thread (shortened): relock when the timer expires,
# and re-apply the expected pin level every second (watchdog).
expired = (self._state is LockState.UNLOCKED
           and time.monotonic() >= self._deadline)
if expired:
    self._apply(False)
    self._state = LockState.LOCKED
    self._deadline = 0.0
else:
    self._apply(self._state is LockState.UNLOCKED)
```

## 2. Door code check with hashing and lockout

File: `app/security.py`

The door code is never stored as plain text. It is stored as a PBKDF2-SHA256 hash with a random salt (200,000 rounds). After 3 wrong tries the keypad locks itself, and each new lockout lasts longer than the last.

```python
def hash_passcode(passcode: str, salt: str, iterations: int) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", passcode.encode("utf-8"), bytes.fromhex(salt), iterations
    ).hex()


def verify(self, passcode: str) -> AttemptResult:
    with self._lock:
        remaining = self.lockout_remaining()
        if remaining > 0:
            return AttemptResult(False, True, 0, remaining, "locked_out")
        expected = self.config.get("security", "passcode_hash")
        salt = self.config.get("security", "passcode_salt")
        iterations = self.config.getint("security", "pbkdf2_iterations", 200000)
        candidate = hash_passcode(passcode, salt, iterations)

        if hmac.compare_digest(candidate, expected):   # constant-time compare
            self._failures = 0
            self._lockout_level = 0
            self._lockout_until = 0.0
            self._save_state()
            return AttemptResult(True, False, self._max_attempts(), 0.0, "ok")

        self._failures += 1
        if self._failures >= self._max_attempts():
            self._lockout_level += 1
            self._lockout_until = time.time() + self._lockout_duration(self._lockout_level)
            self._failures = 0
            self._save_state()
            self.events.warning("keypad.lockout", "too many failures, locked out ...")
            return AttemptResult(False, True, 0, self.lockout_remaining(), "locked_out")

        self._save_state()
        return AttemptResult(False, False, self.remaining_attempts(), 0.0, "wrong")
```

## 3. Face recognition (OpenCV YuNet + SFace)

File: `app/face.py`

YuNet finds faces in the camera picture. SFace turns each face into a 128-number "embedding". The door compares this embedding with every enrolled face using cosine similarity. It opens only when the same person matches 3 frames in a row with a score of at least 0.45. No photos of users are stored, only the embeddings.

```python
class FaceEngine:
    """YuNet + SFace.  Not thread-safe: only the worker thread uses it."""

    def __init__(self, config: Config):
        import cv2
        self._detector = cv2.FaceDetectorYN.create(
            str(config.path_for("face", "detector_model")), "", (DETECT_WIDTH, 240),
            config.getfloat("face", "detect_score", 0.8), 0.3, 50)
        self._recognizer = cv2.FaceRecognizerSF.create(
            str(config.path_for("face", "recognizer_model")), "")

    def embed(self, frame, face):
        """Unit-length 128-d embedding of one detected face."""
        aligned = self._recognizer.alignCrop(frame, face)
        return _unit(self._recognizer.feature(aligned).flatten().astype("float32"))


class Gallery:
    def best(self, embedding, exclude=None):
        """Closest enrolled user and the cosine similarity to them."""
        if self._matrix is None:
            return None, 0.0
        scores = self._matrix @ embedding          # all users in one step
        i = int(scores.argmax())
        return self._owners[i], float(scores[i])
```

```python
# Deciding to open (shortened from _watch_step)
user_id, score = self._gallery.best(engine.embed(frame, face))
threshold = cfg.getfloat("face", "match_threshold", 0.45)
if user_id is not None and score >= threshold:
    job.streak = job.streak + 1 if user_id == job.streak_user else 1
    job.streak_user = user_id
    if job.streak < cfg.getint("face", "confirm_frames", 3):
        return FACE_CHECKING                     # need more frames first
    _call(job.on_match, user_id, score)          # -> the door opens
    return FACE_MATCH
```

## 4. Fingerprint search (R22 / AS608-type sensor over UART)

File: `app/fingerprint.py`

The sensor stores the fingerprint templates itself. The Pi asks it to take an image, convert it to a template, and search its library. The answer is the slot number and a confidence score, and the slot is linked to a user in `users.json`.

```python
def identify(self, progress, cancelled) -> tuple[int, int]:
    self.open()
    progress(1, 2, "Place your finger on the sensor")
    self._sensor.capture(timeout=10.0)          # GenImg
    if cancelled():
        self._sensor.cancel()
        raise Cancelled("Scan cancelled.")
    self._sensor.image_to_buffer(1)             # Img2Tz
    progress(2, 2, "Matching")
    return self._sensor.search(1, 0, self._capacity())   # Search -> (slot, score)
```

## 5. RFID / NFC card check (PN532 over I2C)

File: `app/nfc.py`

The card's ID number (UID) is never saved as it is. A keyed hash (HMAC-SHA256) of it is saved instead. Unknown cards count towards a lockout, like wrong door codes do.

```python
def card_id(self, uid: bytes) -> str:
    """What users.json keeps for a card: a keyed hash of its UID."""
    return hmac.new(self._key(), uid, hashlib.sha256).hexdigest()[:32]

def check(self, uid: bytes) -> CardCheck:
    tag = self.tag(uid)
    if self.limiter.lockout_remaining() > 0:
        return CardCheck(False, tag=tag, reason="locked_out", ...)
    found = self.users.find_card(self.card_id(uid))
    if found is not None:
        user, _card = found
        if not user.enabled:
            return CardCheck(False, user=user, tag=tag, reason="disabled")
        self.limiter.record(True)
        return CardCheck(True, user=user, tag=tag, reason="ok")
    attempt = self.limiter.record(False, "card")
    self.events.warning("card.deny", f"unknown card …{tag} ...")
    return CardCheck(False, tag=tag, reason="unknown", attempt=attempt, ...)
```

## 6. One-time guest codes (temporary codes)

Files: `app/temp_codes.py`, `app/ui/screens.py`

The owner can make a guest code from WhatsApp. It is stored hashed, it expires after the chosen time, and it works only once. The keypad tries guest codes first, so a guest code never counts as a wrong door code.

```python
def add(self, code, seconds) -> int:
    normal = normalize_code(code)
    if normal is None:
        raise ValueError(f"code must be {MIN_DIGITS}-{MAX_DIGITS} digits, as a string")
    digest = hash_passcode(normal, self._salt, self._iterations)
    with self._lock:
        ...
        entry = {"id": code_id, "hash": digest, "expires": time.time() + seconds}
        self._codes = others + [entry]
        self._save()
    return seconds

def consume(self, code_id: str) -> bool:
    """Delete the code; True only if it was still live (single use)."""
    ...
```

```python
# Keypad (HomeScreen._submit): checked on a background thread so the screen never freezes
def work():
    temp_id = None
    if self.ctx.passcode.lockout_remaining() <= 0:
        temp_id = self.ctx.temp_codes.match(code)
    result = None if temp_id else self.ctx.passcode.verify(code)
    self.app.post(self._verified, result, temp_id)

threading.Thread(target=work, name="verify", daemon=True).start()
```

## 7. Fire and smoke alarm (opens the door and alerts)

File: `app/hazard.py`

The sensors are read 10 times a second. An alarm counts only after the sensor stays active for a full window (1 s for fire, 3 s for smoke), which filters out glitches. On an alarm the door opens, the buzzer sounds, and a WhatsApp alert is queued. While the alarm lasts, the door opens again whenever it has been shut for 20 seconds.

```python
if sensor.state == STATE_OK:
    window = spec.confirm_seconds
    sensor.samples.append((now, active))
    while sensor.samples and sensor.samples[0][0] < now - window:
        sensor.samples.popleft()
    if not active:
        return False
    if window > 0:
        if now - sensor.window_start < window:
            return False                       # not a full window of samples yet
        hits = sum(1 for _t, a in sensor.samples if a)
        if hits < ACTIVE_RATIO * len(sensor.samples):
            return False
    self._trigger(sensor, now)
    return self._set(sensor, STATE_ALARM)
```

```python
def _trigger(self, sensor, now):
    kind = sensor.spec.kind
    self._log("warning", f"hazard.{kind}", f"{kind.upper()} DETECTED on GPIO{sensor.spec.pin}")
    door = None
    if self.open_door:
        door = "opened" if self._unlock(f"{kind} alarm") else "failed"
    self.alerts.add(kind, "detected", alert_text(kind, "detected", door),
                    door_opened=door == "opened")
```

## 8. Remote control API (Flask, protected by a secret key)

File: `app/api.py`

A small web API runs on the Pi and listens only on the Pi itself (127.0.0.1). Every request must carry the secret door key, which is compared in constant time. The WhatsApp bot uses this API to open the door, send commands and collect alerts.

```python
@app.before_request
def require_key():
    given = request.headers.get("X-Door-Key")
    if given is not None and hmac.compare_digest(given.encode("utf-8"), expected):
        return None
    refused.record(f"refused {request.method} {request.path} ...")
    return jsonify(ok=False), 401

@app.post("/openDoor")
def open_door():
    if not ctx.lock.unlock(reason="whatsapp"):
        return jsonify(ok=False, error="relay fault"), 500
    return jsonify(ok=True)

@app.get("/alerts")
def alerts_list():
    """Alerts the bot has not acknowledged yet, oldest first."""
    ctx.alerts.polled()
    return jsonify(ok=True, alerts=ctx.alerts.pending())

@app.post("/alerts/ack")
def alerts_ack():
    up_to = request.get_json(force=True, silent=True).get("id")
    return jsonify(ok=True, removed=ctx.alerts.ack(up_to))
```

## 9. WhatsApp bot (Node.js + Baileys)

File: `whatsapp/bot.js`

The bot is linked to WhatsApp as a linked device. It passes each message from the owner to the door's `/command` API and sends back the reply, with a photo when there is one. Every 2 seconds it also collects new alerts (wrong code, doorbell, fire, and so on) and sends them. Commands older than 90 seconds are ignored, so a message delayed by a network outage cannot open the door hours later.

```javascript
async function onMessage (msg) {
  const asker = await whoIsAsking(msg)          // only the owner(s)
  if (!asker) return
  const text = textOf(msg.message)
  const age = Date.now() / 1000 - Number(msg.messageTimestamp || 0)
  if (age > STALE_SECONDS) return               // too old: never act on it
  const result = await (await door('POST', '/command',
    { text, from: asker.from, self: asker.selfChat }, 90000)).json()
  const texts = textsIn(result.texts, result.reply)
  if (texts.length) await send(asker.jid, texts, await photoBytes(result.photo))
}

async function pumpAlerts () {                  // runs every 2 seconds
  let { alerts } = await (await door('GET', '/alerts')).json()
  for (const alert of alerts) {
    const texts = inLanguages(alert.texts, alert.message, 'ar')
    const image = texts.length ? await photoBytes(alert.photo) : null
    for (const jid of alertTargets()) await send(jid, texts, image)
    // Acknowledged only once every message went out.
    await door('POST', '/alerts/ack', { id: alert.id })
  }
}
```

## 10. Understanding WhatsApp commands (keywords first, AI second)

Files: `app/commands.py`, `app/ai.py`

Known commands (open, lock, status, photo, guest code, and so on) are matched by keywords in Arabic, Gulf dialect and English, so they cost nothing. Only a message the keywords don't understand is sent to the OpenAI API. The AI can act only through a fixed list of tools, such as `open_door` and `get_status`.

```python
def handle(self, text: str, sender: str = "", self_chat: bool = False) -> dict:
    raw = (text or "").strip()
    ar = has_arabic(raw) or not any(ch.isalpha() for ch in raw)
    if not self._authorized(sender):
        return self._result("denied", Texts(
            "🚫 هذا الرقم غير مصرّح له بالتحكم بالباب.",
            "🚫 This number is not allowed to control the door."), ar=ar)
    toks = tokens(raw)
    intent = self._intent(toks, "?" in raw or "؟" in raw, pending)
    result = getattr(self, "_do_" + intent)(toks, ar, sender)
    if not result["handled"] and self.ai.ready:
        result = self.ai.answer(raw, sender, ar, self_chat, fallback=result)
    return result
```

```python
# One of the AI tools (strict JSON schema), from app/ai.py
_tool("open_door",
      "Unlock the front door now; it locks again by itself after a few seconds. "
      "Only when the owner's latest message clearly asks to open the door right now. "
      "Never for a question, a negation (don't open), a condition (if Ahmed comes), "
      "a later time (at five, in an hour) or quoted words. If unsure, ask instead."),
```

## 11. Every event recorded, with a photo and an alert

File: `app/recorder.py`

Each line in the event log is sorted into a category (entry, denied, doorbell, alarm). It is saved to a local SQLite database, a camera snapshot is attached when useful, and a WhatsApp alert is queued.

```python
def _handle(self, ts, level, event, message):
    record = classify(event, message, level, ...)
    if record is None:
        return
    photo = self._picture(record.photo, ts) if record.photo else ""
    self.history.add(record.category, record.method, record.person, event, message,
                     level, photo, ts)
    if self.cloud is not None:
        self.cloud.kick()                       # upload to Supabase soon
    if record.alert:
        self._alert(record, photo, ts)          # -> WhatsApp
```

## 12. Cloud sync to Supabase

File: `app/cloud.py`

A background thread uploads the new event rows and photos to Supabase over its REST API, and sends a "heartbeat" status row so the dashboard can show that the door is online. When there is no internet, nothing is lost: rows wait in SQLite and go up later.

```python
def _sync_once(self) -> bool:
    rows = history.pending_rows(ROW_BATCH)
    if rows:
        self._upsert(self.table, "uid", [self._cloud_row(r) for r in rows])
        history.mark_rows_synced([r["id"] for r in rows])
    for name in history.pending_photos(PHOTO_BATCH):
        path = history.photo_path(name)
        self._upload(cloud_photo_path(name), path.read_bytes())
        history.mark_photo_synced(name)
    if time.monotonic() >= self._next_status:
        self._heartbeat()                       # "door online" on the dashboard
    ...

def _upsert(self, table, key, rows):
    response = self._session.post(
        f"{self.url}/rest/v1/{quote(table)}", params={"on_conflict": key}, json=rows,
        headers={"Prefer": "resolution=merge-duplicates,return=minimal"}, ...)
```

## 13. Two roles in the database (row-level security)

File: `supabase/schema.sql`

The dashboard has two roles. An **admin** sees everything. A **member** sees entries, doorbell rings, alarms and refused attempts, but no photos and no account changes. The rule is enforced inside the database itself, so it cannot be bypassed from the browser.

```sql
create policy "door members read events" on public.door_events
  for select to authenticated
  using (
    case (select public.door_role())
      when 'admin' then true
      when 'member' then
        category in ('entry', 'doorbell', 'alarm')
        or (category = 'denied' and method in ('keypad', 'face', 'fingerprint', 'card'))
      else false
    end
  );

create policy "door admins read photos" on storage.objects
  for select to authenticated
  using (bucket_id = 'door-photos' and (select public.door_role()) = 'admin');
```

## 14. Web dashboard: loading events and live updates (React + TypeScript)

File: `web/src/lib/cloud.ts`

The dashboard reads the events page by page and subscribes to live changes, so a new entry appears on the screen without a refresh.

```typescript
async events(fromISO: string): Promise<DoorEvent[]> {
  let out: DoorEvent[] = [];
  for (let page = 0; page < MAX_PAGES; page++) {
    const { data, error } = await this.client.from(CFG.table).select(COLUMNS).gte("ts", fromISO)
      .order("ts", { ascending: false }).range(page * PAGE, page * PAGE + PAGE - 1);
    if (error) throw error;
    out = out.concat(data as DoorEvent[]);
    if (data.length < PAGE) break;
  }
  return out;
}

subscribe(onEvent, onStatus, onLive): void {
  this.channel = this.client.channel("door-dashboard")
    .on("postgres_changes", { event: "INSERT", schema: "public", table: CFG.table },
        (payload) => onEvent(payload.new as DoorEvent))
    .on("postgres_changes", { event: "*", schema: "public", table: CFG.statusTable },
        (payload) => onStatus(payload.new as DoorStatus))
    .subscribe((status) => onLive(status === "SUBSCRIBED"));
}
```
